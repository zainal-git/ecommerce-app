// public/sw.js - Enhanced with Caching
const CACHE_NAME = 'ecommerce-v2.0.0';
const API_CACHE_NAME = 'ecommerce-api-v1';
const STATIC_CACHE_NAME = 'ecommerce-static-v1';

// Check if we're in development mode
const isDevelopment = self.location.hostname === 'localhost' || 
                     self.location.hostname === '127.0.0.1';

// URLs to cache during install
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/src/main.js',
  '/src/app.js',
  '/src/config/api.js',
  '/src/utils/auth.js',
  '/src/utils/view-transition.js',
  '/src/utils/notification-service.js',
  '/src/components/header.js',
  '/src/components/footer.js',
  '/src/views/home-view.js',
  '/src/views/products-view.js',
  '/src/views/map-view.js',
  '/src/views/add-product-view.js',
  '/src/views/login-view.js',
  '/src/styles/main.css',
  '/manifest.json'
];

// External resources to cache
const EXTERNAL_ASSETS = [
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'
];

// API endpoints to cache (with network-first strategy)
const API_ENDPOINTS = [
  '/v1/stories',
  '/v1/stories/guest'
];

// Install event - Cache static assets
self.addEventListener('install', (event) => {
  console.log('Service Worker installing');
  
  if (isDevelopment) {
    console.log('Development mode - skipping cache installation');
    self.skipWaiting();
    return;
  }

  event.waitUntil(
    Promise.all([
      caches.open(STATIC_CACHE_NAME)
        .then(cache => {
          console.log('Caching static assets');
          return cache.addAll(STATIC_ASSETS);
        }),
      caches.open('external-cache')
        .then(cache => {
          console.log('Caching external assets');
          return cache.addAll(EXTERNAL_ASSETS);
        })
    ]).then(() => {
      console.log('All assets cached successfully');
      return self.skipWaiting();
    }).catch(error => {
      console.error('Cache installation failed:', error);
    })
  );
});

// Activate event - Clean up old caches
self.addEventListener('activate', (event) => {
  console.log('Service Worker activating');
  
  if (isDevelopment) {
    console.log('Development mode - skipping cache cleanup');
    self.clients.claim();
    return;
  }

  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          // Delete old caches that don't match current version
          if (cacheName !== CACHE_NAME && 
              cacheName !== STATIC_CACHE_NAME && 
              cacheName !== API_CACHE_NAME &&
              cacheName !== 'external-cache') {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      console.log('Service Worker activated and old caches cleaned');
      return self.clients.claim();
    })
  );
});

// Fetch event - Advanced caching strategies
self.addEventListener('fetch', (event) => {
  // Skip non-GET requests
  if (event.request.method !== 'GET') {
    return;
  }

  // Development mode - bypass cache
  if (isDevelopment) {
    event.respondWith(fetch(event.request));
    return;
  }

  const { request } = event;
  const url = new URL(request.url);

  // Handle API requests with Network First strategy
  if (url.pathname.includes('/v1/')) {
    event.respondWith(handleApiRequest(request));
    return;
  }

  // Handle static assets with Cache First strategy
  if (isStaticAsset(request)) {
    event.respondWith(handleStaticRequest(request));
    return;
  }

  // Handle external resources
  if (isExternalResource(request)) {
    event.respondWith(handleExternalRequest(request));
    return;
  }

  // Default: Network First with cache fallback
  event.respondWith(handleDefaultRequest(request));
});

// API Request Handler - Network First
async function handleApiRequest(request) {
  const cache = await caches.open(API_CACHE_NAME);
  
  try {
    // Try network first
    const networkResponse = await fetch(request);
    
    // Cache successful responses
    if (networkResponse.ok) {
      const responseClone = networkResponse.clone();
      cache.put(request, responseClone);
    }
    
    return networkResponse;
  } catch (error) {
    console.log('Network failed for API, trying cache:', request.url);
    
    // Fallback to cache
    const cachedResponse = await cache.match(request);
    if (cachedResponse) {
      return cachedResponse;
    }
    
    // Return offline page or error for API calls
    return new Response(
      JSON.stringify({ 
        error: 'You are offline and no cached data is available',
        message: 'Please check your internet connection'
      }),
      { 
        status: 503,
        headers: { 'Content-Type': 'application/json' }
      }
    );
  }
}

// Static Asset Handler - Cache First
async function handleStaticRequest(request) {
  const cache = await caches.open(STATIC_CACHE_NAME);
  const cachedResponse = await cache.match(request);
  
  if (cachedResponse) {
    // Return from cache, but update cache in background
    event.waitUntil(
      fetch(request).then(networkResponse => {
        if (networkResponse.ok) {
          cache.put(request, networkResponse.clone());
        }
      }).catch(() => {
        // Ignore errors - we have cached version
      })
    );
    
    return cachedResponse;
  }
  
  // If not in cache, try network
  return fetch(request);
}

// External Resource Handler - Cache First with update
async function handleExternalRequest(request) {
  const cache = await caches.open('external-cache');
  const cachedResponse = await cache.match(request);
  
  if (cachedResponse) {
    return cachedResponse;
  }
  
  // If not in cache, try network and cache
  try {
    const networkResponse = await fetch(request);
    if (networkResponse.ok) {
      cache.put(request, networkResponse.clone());
    }
    return networkResponse;
  } catch (error) {
    // Return generic fallback for external resources
    return new Response('', { status: 404 });
  }
}

// Default Request Handler - Network First
async function handleDefaultRequest(request) {
  try {
    const networkResponse = await fetch(request);
    return networkResponse;
  } catch (error) {
    console.log('Network failed, trying cache for:', request.url);
    
    const cachedResponse = await caches.match(request);
    if (cachedResponse) {
      return cachedResponse;
    }
    
    // Fallback to offline page for navigation requests
    if (request.mode === 'navigate') {
      return caches.match('/');
    }
    
    return new Response('Network error', { status: 408 });
  }
}

// Helper functions
function isStaticAsset(request) {
  return request.url.startsWith(self.location.origin) &&
         (request.url.includes('/src/') ||
          request.url.includes('/styles/') ||
          request.url.endsWith('.js') ||
          request.url.endsWith('.css') ||
          request.url === self.location.origin + '/');
}

function isExternalResource(request) {
  return request.url.includes('unpkg.com') ||
         request.url.includes('openstreetmap.org') ||
         request.url.includes('tile.openstreetmap.org');
}

// Push notifications handler (existing code)
self.addEventListener('push', (event) => {
  console.log('Push notification received', event);
  
  if (!event.data) return;

  let data = {};
  try {
    data = event.data.json();
  } catch (error) {
    console.error('Error parsing push data:', error);
    data = {
      title: 'E-Commerce App',
      message: event.data.text() || 'New notification',
      icon: '/icons/icon-192x192.png'
    };
  }

  const options = {
    body: data.message || data.body || 'New update available',
    icon: data.icon || '/icons/icon-192x192.png',
    badge: '/icons/badge-72x72.png',
    image: data.image || null,
    data: data.data || { url: data.url || '/' },
    actions: data.actions || [],
    tag: data.tag || 'general',
    requireInteraction: data.requireInteraction || false,
    vibrate: [200, 100, 200]
  };

  event.waitUntil(
    self.registration.showNotification(
      data.title || 'E-Commerce App',
      options
    )
  );
});

// Notification click handler (existing code)
self.addEventListener('notificationclick', (event) => {
  console.log('Notification clicked', event);
  
  event.notification.close();

  const urlToOpen = event.notification.data?.url || '/';

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then((windowClients) => {
        for (let client of windowClients) {
          if (client.url.includes(self.location.origin) && 'focus' in client) {
            return client.navigate(urlToOpen).then(client => client.focus());
          }
        }
        
        if (self.clients.openWindow) {
          return self.clients.openWindow(urlToOpen);
        }
      })
  );
});

// Background sync for offline actions
self.addEventListener('sync', (event) => {
  console.log('Background sync triggered:', event.tag);
  
  if (event.tag === 'background-sync') {
    event.waitUntil(doBackgroundSync());
  }
});

async function doBackgroundSync() {
  // Implement background sync for offline actions
  // For example: sync pending product additions when online
  console.log('Performing background sync...');
}

// Handle messages from main thread
self.addEventListener('message', (event) => {
  console.log('Message received in service worker:', event.data);
  
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  if (event.data && event.data.type === 'CACHE_API_DATA') {
    cacheApiData(event.data.payload);
  }
});

// Function to cache API data proactively
async function cacheApiData(data) {
  const cache = await caches.open(API_CACHE_NAME);
  const url = 'https://story-api.dicoding.dev/v1/stories';
  
  const response = new Response(JSON.stringify(data), {
    headers: { 'Content-Type': 'application/json' }
  });
  
  await cache.put(url, response);
  console.log('API data cached proactively');
}