// src/main.js - Enhanced with Better Online/Offline Handling
import { App } from './app.js';
import { PwaService } from './utils/pwa-service.js';

// Check if we're in development
const isDevelopment = window.location.hostname === 'localhost' || 
                     window.location.hostname === '127.0.0.1';

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', async () => {
  try {
    console.log('Initializing E-Commerce App...');
    console.log('Development mode:', isDevelopment);
    console.log('Online status:', navigator.onLine);

    // Initialize PWA features first
    PwaService.init();
    
    // Wait for app to be ready (online) before initializing main app
    if (!navigator.onLine) {
      console.log('App is offline - waiting for connection...');
      PwaService.showMessage('Waiting for internet connection...', 'warning', 0);
      
      // Wait for online event before proceeding
      await new Promise((resolve) => {
        const handleOnline = () => {
          window.removeEventListener('online', handleOnline);
          PwaService.showMessage('Connection established! Loading app...', 'success', 3000);
          resolve();
        };
        window.addEventListener('online', handleOnline);
      });
    }

    // Now initialize the main app
    const app = new App();
    await app.init();
    
    // Initialize service worker for push notifications and caching
    await initializeServiceWorker();
    
    // Check and show install prompt if applicable
    setTimeout(() => {
      checkAndShowInstallPrompt();
    }, 3000);
    
  } catch (error) {
    console.error('Error initializing app:', error);
    
    // Show user-friendly error message
    let errorMessage = 'Failed to initialize app';
    if (!navigator.onLine) {
      errorMessage = 'No internet connection. Please check your connection and refresh.';
    }
    
    PwaService.showMessage(errorMessage, 'error', 10000);
  }
});

// Enhanced service worker registration with development support
async function initializeServiceWorker() {
  if (!('serviceWorker' in navigator)) {
    console.log('Service Workers are not supported in this browser');
    if (isDevelopment) {
      PwaService.showMessage('Service Worker not supported in this browser', 'warning');
    }
    return;
  }

  try {
    // Unregister any existing service workers first (development safety)
    if (isDevelopment) {
      const registrations = await navigator.serviceWorker.getRegistrations();
      for (let registration of registrations) {
        console.log('Unregistering old service worker:', registration);
        await registration.unregister();
      }
      console.log('Cleared old service workers for development');
    }

    const registration = await navigator.serviceWorker.register('/sw.js', {
      scope: '/',
      updateViaCache: 'none'
    });
    
    console.log('Service Worker registered successfully:', registration);

    // Development-specific logging
    if (isDevelopment) {
      console.log('Service Worker scope:', registration.scope);
      console.log('Service Worker state:', registration.active?.state);
    }

    // Check for updates
    registration.addEventListener('updatefound', () => {
      const newWorker = registration.installing;
      console.log('New service worker found:', newWorker);
      
      newWorker.addEventListener('statechange', () => {
        console.log('Service Worker state changed:', newWorker.state);
        if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
          // New update available
          showUpdateNotification(registration);
        }
      });
    });

    // Handle controller change
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      console.log('Service worker controller changed');
      if (!isDevelopment) {
        showUpdateSuccessNotification();
      }
    });

    // Check for updates periodically (only in production)
    if (!isDevelopment) {
      setInterval(() => {
        registration.update().catch(error => {
          console.log('Service Worker update check failed:', error);
        });
      }, 60 * 60 * 1000);
    }

  } catch (error) {
    console.error('Service Worker registration failed:', error);
    
    if (isDevelopment) {
      const errorMsg = `Service Worker Error: ${error.message}. This is normal in development.`;
      PwaService.showMessage(errorMsg, 'warning', 8000);
    } else {
      PwaService.showMessage('Offline features unavailable', 'warning', 5000);
    }
  }
}

// Check and show install prompt
function checkAndShowInstallPrompt() {
  // Don't show install prompt in development
  if (isDevelopment) {
    console.log('Development mode - skipping install prompt');
    return;
  }

  const status = PwaService.getInstallStatus();
  
  if (status.canInstall && !status.isStandalone && status.isAppReady) {
    // Show install prompt after a delay
    setTimeout(() => {
      PwaService.showInstallPrompt();
    }, 2000);
  } else if (!status.isAppReady) {
    console.log('App not ready - install prompt delayed');
  }
}

// Show update notification (only in production)
function showUpdateNotification(registration) {
  if (isDevelopment) {
    console.log('Development mode - skipping update notification');
    return;
  }

  const notification = document.createElement('div');
  notification.className = 'update-notification';
  notification.innerHTML = `
    <div class="update-content">
      <span class="update-icon">🔄</span>
      <div class="update-text">
        <strong>New Version Available</strong>
        <p>A new version of the app is ready</p>
      </div>
    </div>
    <button id="update-btn" class="btn-update">Update Now</button>
  `;
  
  document.body.appendChild(notification);
  
  document.getElementById('update-btn').addEventListener('click', () => {
    if (registration.waiting) {
      registration.waiting.postMessage({ type: 'SKIP_WAITING' });
    }
    notification.remove();
  });

  // Auto remove after 30 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.remove();
    }
  }, 30000);
}

// Show update success notification (only in production)
function showUpdateSuccessNotification() {
  if (isDevelopment) return;
  
  PwaService.showMessage('App updated successfully!', 'success', 3000);
  setTimeout(() => {
    window.location.reload();
  }, 1000);
}

// Handle messages from service worker
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.addEventListener('message', (event) => {
    console.log('Message from service worker:', event.data);
    
    if (event.data && event.data.type === 'NAVIGATE') {
      window.location.href = event.data.url;
    }
    
    if (event.data && event.data.type === 'CACHE_UPDATED') {
      PwaService.showMessage('Content updated for offline use', 'success', 3000);
    }
  });

  // Listen for service worker ready
  navigator.serviceWorker.ready.then((registration) => {
    console.log('Service Worker is ready:', registration);
  });
}

// Development helper: Force reload without service worker
if (isDevelopment) {
  window._forceReload = async () => {
    const registrations = await navigator.serviceWorker.getRegistrations();
    for (let registration of registrations) {
      await registration.unregister();
    }
    window.location.reload();
  };
  
  console.log('Development helpers loaded. Use _forceReload() to clear Service Worker.');
}

// Export for testing purposes
export { initializeServiceWorker, PwaService, isDevelopment };