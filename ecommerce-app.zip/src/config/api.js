export const API_CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  ENDPOINTS: {
    REGISTER: '/register',
    LOGIN: '/login',
    STORIES: '/stories',
    STORIES_GUEST: '/stories/guest',
    NOTIFICATIONS: '/notifications/subscribe'
  }
};

export class ApiService {
  static async request(endpoint, options = {}) {
    const url = `${API_CONFIG.BASE_URL}${endpoint}`;
    
    // Handle FormData (no Content-Type for multipart/form-data)
    const isFormData = options.body instanceof FormData;
    const headers = isFormData 
      ? { ...options.headers }
      : { 
          'Content-Type': 'application/json',
          ...options.headers 
        };

    const config = {
      headers,
      ...options
    };

    // Convert body to JSON if it's not FormData
    if (!isFormData && config.body && typeof config.body === 'object') {
      config.body = JSON.stringify(config.body);
    }

    try {
      const response = await fetch(url, config);
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || `Request failed with status ${response.status}`);
      }
      
      return data;
    } catch (error) {
      throw new Error(error.message || 'Network error');
    }
  }

  static async getStories(token, location = 0) {
    const endpoint = `${API_CONFIG.ENDPOINTS.STORIES}?location=${location}`;
    return this.request(endpoint, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
  }

  static async addStory(token, formData) {
    return this.request(API_CONFIG.ENDPOINTS.STORIES, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`
      },
      body: formData
    });
  }

  static async login(email, password) {
    return this.request(API_CONFIG.ENDPOINTS.LOGIN, {
      method: 'POST',
      body: { email, password }
    });
  }

  static async register(name, email, password) {
    return this.request(API_CONFIG.ENDPOINTS.REGISTER, {
      method: 'POST',
      body: { name, email, password }
    });
  }

  static async subscribeToNotifications(token, subscription) {
    return this.request(API_CONFIG.ENDPOINTS.NOTIFICATIONS, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`
      },
      body: { subscription }
    });
  }

  static async unsubscribeFromNotifications(token) {
    return this.request(API_CONFIG.ENDPOINTS.NOTIFICATIONS, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
  }

  // Method untuk mendapatkan VAPID public key
  static getVapidPublicKey() {
    return 'BCCs2eonMI-6H2ctvFaWg-UYdDv387Vno_bzUzALpB442r2lCnsHmtrx8biyPi_E-1fSGABK_Qs_GlvPoJJqxbk';
  }
}