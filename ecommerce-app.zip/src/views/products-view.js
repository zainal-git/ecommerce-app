import { ApiService } from '../config/api.js';
import { AuthService } from '../utils/auth.js';
import { ViewTransition } from '../utils/view-transition.js';

export class ProductsView {
  constructor() {
    this.element = document.createElement('div');
    this.element.className = 'view products-view';
    this.element.setAttribute('role', 'main');
    this.element.setAttribute('aria-label', 'Products Page');
    this.stories = [];
  }

  async render() {
    this.element.innerHTML = `
      <section class="products-section" aria-labelledby="products-title">
        <div class="section-header">
          <h1 id="products-title">Our Products</h1>
          <div class="filter-controls">
            <label for="location-filter" class="filter-label">Filter by Location:</label>
            <select id="location-filter" class="filter-select" aria-label="Filter products by location availability">
              <option value="0">All Products</option>
              <option value="1">With Location</option>
            </select>
          </div>
        </div>
        
        <div class="loading-spinner" id="loading-spinner" aria-live="polite" aria-label="Loading products">
          Loading products...
        </div>
        
        <div class="products-grid" id="products-grid" role="list" aria-label="List of products">
          <!-- Products will be loaded here -->
        </div>
        
        <div class="error-message" id="error-message" role="alert" aria-live="assertive" hidden>
          <!-- Error messages will be shown here -->
        </div>
      </section>
    `;

    await this.loadProducts();
    this.attachEventListeners();
    await ViewTransition.fadeIn(this.element);
    return this.element;
  }

  async loadProducts(locationFilter = 0) {
    const spinner = this.element.querySelector('#loading-spinner');
    const grid = this.element.querySelector('#products-grid');
    const errorMsg = this.element.querySelector('#error-message');

    try {
      spinner.style.display = 'block';
      grid.style.display = 'none';
      errorMsg.hidden = true;

      const token = AuthService.getToken();
      if (!token) {
        throw new Error('Please login to view products');
      }

      const response = await ApiService.getStories(token, locationFilter);
      this.stories = response.listStory || [];

      if (this.stories.length === 0) {
        grid.innerHTML = `
          <div class="empty-state" role="status">
            <p>No products found. Be the first to add one!</p>
            <a href="#/add-product" class="btn" style="background-color: #8B5CF6; color: white;" data-link>Add Product</a>
          </div>
        `;
      } else {
        grid.innerHTML = this.stories.map(story => `
          <div class="product-card" role="listitem" data-product-id="${story.id}">
            <div class="product-image">
              <img src="${story.photoUrl}" alt="${story.description || 'Product image'}" loading="lazy">
            </div>
            <div class="product-info">
              <h3 class="product-name">${story.name}</h3>
              <p class="product-description">${story.description}</p>
              <div class="product-meta">
                <span class="product-date">${new Date(story.createdAt).toLocaleDateString()}</span>
                ${story.lat && story.lon ? `
                  <span class="product-location" aria-label="Has location information">📍</span>
                ` : ''}
              </div>
            </div>
          </div>
        `).join('');
      }

      grid.style.display = 'grid';
    } catch (error) {
      errorMsg.hidden = false;
      errorMsg.textContent = `Error loading products: ${error.message}`;
      grid.innerHTML = '';
    } finally {
      spinner.style.display = 'none';
    }
  }

  attachEventListeners() {
    const locationFilter = this.element.querySelector('#location-filter');
    locationFilter.addEventListener('change', (e) => {
      this.loadProducts(parseInt(e.target.value));
    });

    // Keyboard navigation for product cards
    const grid = this.element.querySelector('#products-grid');
    if (grid) {
      grid.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          const productCard = e.target.closest('.product-card');
          if (productCard) {
            e.preventDefault();
            const productId = productCard.getAttribute('data-product-id');
            if (productId) {
              window.location.hash = `/product/${productId}`;
            }
          }
        }
      });
    }
  }
}