// src/utils/pwa-service.js - Enhanced with Better Online/Offline Handling
export class PwaService {
  static deferredPrompt = null;
  static isInstalled = false;
  static isDevelopment = window.location.hostname === 'localhost' || 
                        window.location.hostname === '127.0.0.1';
  static isAppReady = false;
  static initialLoad = true;

  static init() {
    if (this.isDevelopment) {
      console.log('PWA Service running in development mode');
    }
    
    this.setupBeforeInstallPrompt();
    this.setupAppInstalled();
    this.setupOnlineOfflineEvents();
    this.checkInitialConnection();
  }

  // Check initial connection status
  static checkInitialConnection() {
    if (!navigator.onLine && this.initialLoad) {
      console.log('Initial load: No internet connection');
      this.showOfflineWarning();
    } else {
      this.isAppReady = true;
    }
    this.initialLoad = false;
  }

  // Handle beforeinstallprompt event
  static setupBeforeInstallPrompt() {
    window.addEventListener('beforeinstallprompt', (e) => {
      console.log('beforeinstallprompt event fired');
      
      // Prevent Chrome 67 and earlier from automatically showing the prompt
      e.preventDefault();
      
      // Stash the event so it can be triggered later
      this.deferredPrompt = e;
      
      // In development, show debug info instead of install prompt
      if (this.isDevelopment) {
        console.log('Install prompt available (development mode)');
        this.showMessage('Install prompt would show in production', 'info', 4000);
        return;
      }
      
      // Update UI to notify the user they can add to home screen
      this.showInstallPrompt();
    });
  }

  // Handle app installed event
  static setupAppInstalled() {
    window.addEventListener('appinstalled', (e) => {
      console.log('PWA was installed');
      this.isInstalled = true;
      this.hideInstallPrompt();
      
      // Show success message
      this.showMessage('App installed successfully!', 'success');
    });
  }

  // Handle online/offline events
  static setupOnlineOfflineEvents() {
    window.addEventListener('online', () => {
      console.log('App is online');
      this.hideOfflineIndicator();
      this.isAppReady = true;
      
      if (!this.isDevelopment) {
        this.showMessage('Connection restored - App is ready', 'success', 3000);
      }
      
      // Dispatch custom event for other components to listen to
      window.dispatchEvent(new CustomEvent('appOnline'));
    });

    window.addEventListener('offline', () => {
      console.log('App is offline');
      this.showOfflineIndicator();
      
      if (!this.isDevelopment && this.isAppReady) {
        this.showMessage('You are currently offline', 'warning', 5000);
      }
      
      // Dispatch custom event for other components to listen to
      window.dispatchEvent(new CustomEvent('appOffline'));
    });

    // Initial check
    if (!navigator.onLine) {
      this.showOfflineIndicator();
      if (this.initialLoad) {
        this.showOfflineWarning();
      }
    } else {
      this.isAppReady = true;
    }
  }

  // Show warning for initial offline load
  static showOfflineWarning() {
    const warningEl = document.createElement('div');
    warningEl.className = 'offline-warning';
    warningEl.innerHTML = `
      <div class="offline-warning-content">
        <div class="warning-icon">⚠️</div>
        <div class="warning-text">
          <h3>Internet Connection Required</h3>
          <p>This app needs an internet connection for the first load. Please check your connection and refresh the page.</p>
          <button id="retry-connection" class="btn-retry">Retry Connection</button>
        </div>
      </div>
    `;
    
    // Add styles for offline warning
    if (!document.querySelector('#offline-warning-styles')) {
      const styles = document.createElement('style');
      styles.id = 'offline-warning-styles';
      styles.textContent = `
        .offline-warning {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.8);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 10000;
          padding: 2rem;
        }
        .offline-warning-content {
          background: white;
          padding: 2rem;
          border-radius: 12px;
          max-width: 500px;
          text-align: center;
          box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }
        .warning-icon {
          font-size: 3rem;
          margin-bottom: 1rem;
        }
        .warning-text h3 {
          margin: 0 0 1rem 0;
          color: #e53e3e;
          font-size: 1.5rem;
        }
        .warning-text p {
          margin: 0 0 1.5rem 0;
          color: #4a5568;
          line-height: 1.5;
        }
        .btn-retry {
          background: #3182ce;
          color: white;
          border: none;
          padding: 0.75rem 1.5rem;
          border-radius: 6px;
          font-size: 1rem;
          cursor: pointer;
          transition: background-color 0.2s;
        }
        .btn-retry:hover {
          background: #2c5aa0;
        }
      `;
      document.head.appendChild(styles);
    }
    
    document.body.appendChild(warningEl);
    
    // Add retry functionality
    const retryBtn = document.getElementById('retry-connection');
    retryBtn.addEventListener('click', () => {
      if (navigator.onLine) {
        window.location.reload();
      } else {
        this.showMessage('Still offline. Please check your connection.', 'error', 3000);
      }
    });
    
    // Auto remove when online
    const removeWarning = () => {
      if (warningEl.parentNode) {
        warningEl.remove();
        window.removeEventListener('online', removeWarning);
      }
    };
    window.addEventListener('online', removeWarning);
  }

  // Show install prompt
  static showInstallPrompt() {
    // Don't show in development
    if (this.isDevelopment) {
      console.log('Development mode - install prompt suppressed');
      return;
    }

    // Check if already installed
    if (this.isInstalled) {
      return;
    }

    // Only show install prompt if app is ready (online)
    if (!this.isAppReady) {
      console.log('App not ready - delaying install prompt');
      return;
    }

    const installPrompt = document.getElementById('install-prompt');
    if (installPrompt) {
      installPrompt.hidden = false;
      
      // Add event listeners for buttons
      const installConfirm = document.getElementById('install-confirm');
      const installCancel = document.getElementById('install-cancel');
      
      if (installConfirm) {
        installConfirm.onclick = () => this.installApp();
      }
      
      if (installCancel) {
        installCancel.onclick = () => this.hideInstallPrompt();
      }
    }
  }

  // Hide install prompt
  static hideInstallPrompt() {
    const installPrompt = document.getElementById('install-prompt');
    if (installPrompt) {
      installPrompt.hidden = true;
    }
  }

  // Install app
  static async installApp() {
    if (this.isDevelopment) {
      this.showMessage('Install would work in production', 'info', 3000);
      return;
    }

    if (!this.deferredPrompt) {
      console.log('No install prompt available');
      this.showMessage('Installation not available', 'error');
      return;
    }

    // Ensure app is ready before installation
    if (!this.isAppReady) {
      this.showMessage('Please wait for app to be ready', 'warning');
      return;
    }

    try {
      // Show the install prompt
      this.deferredPrompt.prompt();
      
      // Wait for the user to respond to the prompt
      const { outcome } = await this.deferredPrompt.userChoice;
      
      console.log(`User response to the install prompt: ${outcome}`);
      
      // We've used the prompt, and can't use it again, throw it away
      this.deferredPrompt = null;
      
      // Hide the install prompt
      this.hideInstallPrompt();
      
      if (outcome === 'accepted') {
        this.showMessage('App installation started...', 'success', 3000);
      }
      
    } catch (error) {
      console.error('Error installing app:', error);
      this.showMessage('Failed to install app', 'error');
    }
  }

  // Show offline indicator
  static showOfflineIndicator() {
    const offlineIndicator = document.getElementById('offline-indicator');
    if (offlineIndicator) {
      offlineIndicator.hidden = false;
    }
  }

  // Hide offline indicator
  static hideOfflineIndicator() {
    const offlineIndicator = document.getElementById('offline-indicator');
    if (offlineIndicator) {
      offlineIndicator.hidden = true;
    }
  }

  // Check if app is running in standalone mode
  static isRunningStandalone() {
    return window.matchMedia('(display-mode: standalone)').matches || 
           window.navigator.standalone === true;
  }

  // Check if app can be installed
  static canInstall() {
    return this.deferredPrompt !== null && !this.isInstalled && this.isAppReady;
  }

  // Get PWA installation status
  static getInstallStatus() {
    return {
      canInstall: this.canInstall(),
      isInstalled: this.isInstalled,
      isStandalone: this.isRunningStandalone(),
      isAppReady: this.isAppReady,
      isOnline: navigator.onLine
    };
  }

  // Wait for app to be ready
  static waitForAppReady() {
    return new Promise((resolve) => {
      if (this.isAppReady) {
        resolve(true);
      } else {
        const checkReady = () => {
          if (this.isAppReady) {
            window.removeEventListener('appOnline', checkReady);
            resolve(true);
          }
        };
        window.addEventListener('appOnline', checkReady);
      }
    });
  }

  // Show message to user
  static showMessage(message, type = 'info', duration = 4000) {
    // Don't show messages if app isn't ready (except errors)
    if (!this.isAppReady && type !== 'error') {
      return null;
    }

    // Create message element
    const messageEl = document.createElement('div');
    messageEl.className = `pwa-message pwa-message-${type}`;
    messageEl.innerHTML = `
      <span class="pwa-message-text">${message}</span>
      <button class="pwa-message-close" aria-label="Close message">×</button>
    `;
    
    // Add styles if not already added
    if (!document.querySelector('#pwa-message-styles')) {
      const styles = document.createElement('style');
      styles.id = 'pwa-message-styles';
      styles.textContent = `
        .pwa-message {
          position: fixed;
          top: 20px;
          right: 20px;
          background: white;
          padding: 1rem 1.5rem;
          border-radius: 8px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.15);
          z-index: 10000;
          display: flex;
          align-items: center;
          gap: 1rem;
          max-width: 400px;
          animation: slideInRight 0.3s ease;
        }
        .pwa-message-success {
          border-left: 4px solid #10b981;
        }
        .pwa-message-error {
          border-left: 4px solid #ef4444;
        }
        .pwa-message-warning {
          border-left: 4px solid #f59e0b;
        }
        .pwa-message-info {
          border-left: 4px solid #2563eb;
        }
        .pwa-message-close {
          background: none;
          border: none;
          font-size: 1.5rem;
          cursor: pointer;
          padding: 0;
          width: 24px;
          height: 24px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #718096;
        }
        .pwa-message-close:hover {
          color: #2d3748;
        }
        @keyframes slideInRight {
          from {
            transform: translateX(100%);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
      `;
      document.head.appendChild(styles);
    }
    
    document.body.appendChild(messageEl);
    
    // Add close event
    const closeBtn = messageEl.querySelector('.pwa-message-close');
    closeBtn.addEventListener('click', () => {
      messageEl.remove();
    });
    
    // Auto remove after duration
    if (duration > 0) {
      setTimeout(() => {
        if (messageEl.parentNode) {
          messageEl.remove();
        }
      }, duration);
    }
    
    return messageEl;
  }

  // Check connection status
  static checkConnection() {
    return navigator.onLine;
  }

  // Force refresh when coming online
  static refreshOnOnline() {
    if (!this.isAppReady && navigator.onLine) {
      console.log('Coming online - refreshing app');
      window.location.reload();
    }
  }
}